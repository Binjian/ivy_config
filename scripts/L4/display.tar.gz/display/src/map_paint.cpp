#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <fstream>
#include <iostream>
#include <cmath>
#include <pthread.h>
#include "json/json.h"
#include "nio_msgs/location.h"
#include "nio_msgs/trajectory.h"
#include <tf/transform_broadcaster.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>


ros::Publisher marker_pub;
ros::Publisher marker_pub1;
ros::Publisher marker_pub2;
visualization_msgs::Marker *line;
visualization_msgs::MarkerArray line_array;
int line_num;
visualization_msgs::Marker traj;
int traj_num;
ros::Time loc_time;

void* publish_thread(void*){
	ros::Rate r(30);
    while (ros::ok()){
		marker_pub.publish(line_array);
		r.sleep();
    }
	return NULL;
}

void parse_location(const nio_msgs::location::ConstPtr& msg){
	double x,y,z,yaw;
	y = msg->northing;
	x = msg->easting;
	z = 0.0;
	yaw = msg->yaw;
	loc_time = msg->header.stamp;

	static tf::TransformBroadcaster br;
    tf::Transform trans;
    tf::Quaternion pose_q;

    trans.setOrigin(tf::Vector3(x, y, z));
    pose_q.setRPY(0, 0, yaw);
    trans.setRotation(pose_q);
	tf::Transform trans1;
	trans1.setOrigin(tf::Vector3(x+1, y, z));
	trans1.setRotation(pose_q);
    br.sendTransform( tf::StampedTransform(trans, ros::Time::now(), "map" ,"base_link"));
	br.sendTransform( tf::StampedTransform(trans1, ros::Time::now(), "map" ,"pandar"));
}

void parse_trajectory(const nio_msgs::trajectory::ConstPtr& msg){
	traj.header.frame_id = "/base_link";
	traj.header.stamp = ros::Time::now();
	traj.ns = "points_and_lines";
	traj.action = visualization_msgs::Marker::ADD;
	traj.pose.orientation.w = 1.0;
	traj.id = 100;
	traj.type = visualization_msgs::Marker::LINE_STRIP;
	traj.scale.x = 0.1;
	traj.color.r = 0.6;
	traj.color.g = 1.0;
	traj.color.a = 0.6;
	traj.points.clear();
	traj_num = msg->pts.size();
	geometry_msgs::Point p;
	for(int i=0; i<traj_num; i++){
		p.x = msg->pts[i].x;
		p.y = msg->pts[i].y;
		p.z = 0;
		traj.points.push_back(p);
	}
	marker_pub1.publish(traj);
}

int main( int argc, char** argv )
{
	ros::init(argc, argv, "points_and_lines");
	ros::NodeHandle n;
	ros::Subscriber sub = n.subscribe("location_msg", 100, parse_location);
	ros::Subscriber sub1 = n.subscribe("trajectory_msg", 100, parse_trajectory);
	marker_pub = n.advertise<visualization_msgs::MarkerArray>("map_marker", 20);
	marker_pub1 = n.advertise<visualization_msgs::Marker>("traj_marker", 10);
	
	ros::NodeHandle pnh("~");
	std::string map_data;
	pnh.param<std::string>("map_data", map_data, "src/map/data/road.json");
	const char *filename = map_data.c_str();
	if(argc>=2){
	    filename = argv[1];
	}else{
	    filename = map_data.c_str();
	}

	Json::Reader reader;
	Json::Value root;
	Json::Value link;
	Json::Value id_js;
	Json::Value point_js;
	std::ifstream fs;
	fs.open(filename );
	if(!fs.is_open()){
	    ROS_INFO("ERROR !! CAN NOT OPEN FILE");
	}
	if(reader.parse(fs, root, true)){
	    ROS_INFO("start parse json file");
	    std::string code;
		int link_num = root.size();
		line_num = 0;
		for(int i = 0;i<link_num;i++){
			line_num += root[i]["link"].size();
		}
	    line = new visualization_msgs::Marker[line_num];
	    ROS_INFO("%d frame in file",line_num);
	    geometry_msgs::Point p;
		int nl = 0;
	    for(int i = 0; i < link_num; i++){
			for(int j = 0; j < int(root[i]["link"].size()); j++){
				line[nl + j].header.frame_id = "/map";
				line[nl + j].header.stamp = ros::Time::now();
				line[nl + j].ns = "points_and_lines";
				line[nl + j].action = visualization_msgs::Marker::ADD;
				line[nl + j].pose.orientation.w = 1.0;
				line[nl + j].id = nl + j;
				line[nl + j].type = visualization_msgs::Marker::LINE_STRIP;
				line[nl + j].scale.x = 0.1;
				int type = root[i]["link"][j]["type"].asInt();
				if(type == 1 || type == 2 || type == 11 || type == 9 || type == 333 || type == 111){
					line[nl + j].color.g = 0.3;
					line[nl + j].color.r = 0.3;
					line[nl + j].color.b = 0.3;
					line[nl + j].color.a = 0.3;
					if(type == 2){
						line[nl + j].color.a = 0.3;
					}
				}else if(type == 6 || type == 36 || type == 46 || type == 76 || type == 5){
					line[nl + j].color.g = 0.5;
					line[nl + j].color.r = 0.5;
					line[nl + j].color.b = 0.5;
					line[nl + j].color.a = 0.5;
				}else{
					continue;
				}
				point_js = root[i]["link"][j]["point"];
				int point_num = point_js.size();
				ROS_INFO("%d point in line %d, type %d",point_num, root[i]["link"][j]["ref_id"].asInt(),type);
				for(int k = 0; k < point_num; k++){
					p.x = point_js[k]["x"].asDouble();
					p.y = point_js[k]["y"].asDouble();
					p.z = 0;
					line[nl + j].points.push_back(p);
				}
			}
		    nl += root[i]["link"].size();
	    }
		for(int i = 0; i < line_num; i++){
			line_array.markers.push_back(line[i]);
		}	  
	}
	pthread_t id1;
    int ret = pthread_create(&id1,NULL,publish_thread,NULL);
    if(ret!=0)  {  
        printf("Create pthread0 error!\n");  
        return -1;  
    } 
	ros::spin();
	
	pthread_join(id1,NULL);
	delete[] line;
	return 0;
}
// %EndTag(FULLTEXT)%
