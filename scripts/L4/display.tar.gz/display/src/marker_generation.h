#ifndef MARKER_GENERATION_H_
#define MARKER_GENERATION_H_

#include "ros/ros.h"
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>

#include "prediction_object.h"


visualization_msgs::Marker generateTrajMarker(std::vector<geometry_msgs::Point> p_array, ros::Time loc_time);
visualization_msgs::Marker generateMapMarker(std::vector<geometry_msgs::Point> p_array, int type, int id, ros::Time loc_time);
visualization_msgs::Marker generatePercptMarker(obj_box per_box, int id, ros::Time loc_time);
visualization_msgs::Marker generatePredictMarker(prediction_box predict_box, int id, ros::Time loc_time);
visualization_msgs::Marker generatePredictTextMarker(prediction_box predict_box, int id, ros::Time loc_time);


visualization_msgs::Marker generateMapMarker(std::vector<geometry_msgs::Point> p_array, int type, int id, ros::Time loc_time)
{
    visualization_msgs::Marker mapMarker;
    
    mapMarker.header.frame_id = "/map";
    mapMarker.header.stamp = loc_time;
    mapMarker.ns = "points_and_lines";
    mapMarker.action = visualization_msgs::Marker::ADD;
    mapMarker.pose.orientation.w = 1.0;
    mapMarker.id = id;
    mapMarker.type = visualization_msgs::Marker::LINE_STRIP;
    mapMarker.scale.x = 0.1;
    mapMarker.lifetime = ros::Duration(1.0);

    // central line
    if(type == 1 | type == 11 | type == 5){
        mapMarker.color.g = 0.5;
        mapMarker.color.r = 0.5;
        mapMarker.color.b = 0.5;
        mapMarker.color.a = 0.5;
    }
    // white line yellow line
    else if( type == 6 || type == 46 || type == 76 || type == 36)
    {
        mapMarker.color.g = 0.8;
        mapMarker.color.r = 0.8;
        mapMarker.color.b = 0.8;
        mapMarker.color.a = 1.0;
    }
    // dash line
    else if( type == 56 || type == 16 || type == 66 || type == 26)
    {
        mapMarker.color.g = 0.8;
        mapMarker.color.r = 0.8;
        mapMarker.color.b = 0.8;
        mapMarker.color.a = 0.6;
    }
    // border
    else if( type == 2)
    {
        mapMarker.color.g = 0.0;
        mapMarker.color.r = 0.8;
        mapMarker.color.b = 0.0;
        mapMarker.color.a = 0.6;
    }
    else{
        mapMarker.color.g = 0.0;
        mapMarker.color.r = 0.0;
        mapMarker.color.b = 0.0;
        mapMarker.color.a = 0.0;
    }

    geometry_msgs::Point p;
	for(int i=0; i<p_array.size(); i++)
	{
		p.x = p_array[i].x;
		p.y = p_array[i].y;
		p.z = p_array[i].z;
		mapMarker.points.push_back(p);
	}

    return mapMarker;
}

visualization_msgs::Marker generateTrajMarker(std::vector<geometry_msgs::Point> p_array, ros::Time loc_time)
{
    visualization_msgs::Marker trajMarker;
    
    trajMarker.header.frame_id = "/base_link";
	trajMarker.header.stamp = loc_time;
	trajMarker.ns = "points_and_lines";
	trajMarker.action = visualization_msgs::Marker::ADD;
    trajMarker.lifetime = ros::Duration(0.2);

	trajMarker.pose.orientation.w = 1.0;
	trajMarker.id = 100;
	trajMarker.type = visualization_msgs::Marker::LINE_STRIP;
	trajMarker.scale.x = 0.1;
	trajMarker.color.r = 0.6;
	trajMarker.color.g = 1.0;
	trajMarker.color.a = 0.6;
	trajMarker.points.clear();

	geometry_msgs::Point p;
	for(int i=0; i<p_array.size(); i++)
	{
		p.x = p_array[i].x;
		p.y = p_array[i].y;
		p.z = p_array[i].z;
		trajMarker.points.push_back(p);
	}
    
    return trajMarker;
}


visualization_msgs::Marker generatePercptMarker(obj_box per_box, int id, ros::Time loc_time)
{
    visualization_msgs::Marker percpt_line_list;
	percpt_line_list.header.frame_id = "/map";
	percpt_line_list.header.stamp = loc_time;
    percpt_line_list.ns = "basic_shapes";
    percpt_line_list.type = visualization_msgs::Marker::LINE_LIST;
    percpt_line_list.action = visualization_msgs::Marker::ADD;
    percpt_line_list.lifetime = ros::Duration(0.2);

    percpt_line_list.id = id;
    percpt_line_list.scale.x = 0.1;
	percpt_line_list.color.g = 1.0;

    geometry_msgs::Point p;
    int vert_num = per_box.x.size();
    for (int c_vert = 0; c_vert < vert_num-1; c_vert++) {
        //start point
        p.x = per_box.x[c_vert];
        p.y = per_box.y[c_vert];
        p.z = 0;
        percpt_line_list.points.push_back(p);
        //end point
        p.x = per_box.x[c_vert+1];
        p.y = per_box.y[c_vert+1];
        p.z = 0;
        percpt_line_list.points.push_back(p);

    }
    return percpt_line_list;
}

visualization_msgs::Marker generatePercptTextMarker(obj_box percpt_obj_box, int id, ros::Time loc_time)
{
    visualization_msgs::Marker percpt_text_marker;
	percpt_text_marker.header.frame_id = "/map";
	percpt_text_marker.header.stamp = loc_time;
	percpt_text_marker.ns = "basic_shapes";
	percpt_text_marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
	percpt_text_marker.action = visualization_msgs::Marker::ADD;
    percpt_text_marker.lifetime = ros::Duration(0.1);

	//string list is blue
	percpt_text_marker.color.g = 1.0;
	percpt_text_marker.color.b = 1.0;
	percpt_text_marker.color.a = 1.0;

	percpt_text_marker.pose.position.z = 0;
	percpt_text_marker.pose.orientation.x = 0.0;
	percpt_text_marker.pose.orientation.y = 0.0;
	percpt_text_marker.pose.orientation.z = 0.0;
	percpt_text_marker.pose.orientation.w = 1.0;

	percpt_text_marker.scale.x = 1;
	percpt_text_marker.scale.y = 1;
	percpt_text_marker.scale.z = 1;

    char text_str[300];
	memset(text_str, 0 ,300);
    double x_cen = percpt_obj_box.x_cen;
    double y_cen = percpt_obj_box.y_cen;

    percpt_text_marker.id = id;
    percpt_text_marker.pose.position.x = x_cen;
    percpt_text_marker.pose.position.y = y_cen;
    percpt_text_marker.pose.position.z = 0;
    sprintf(text_str,"id=%d",percpt_obj_box.id);
    std::string text(text_str);
    percpt_text_marker.text = text;

    return percpt_text_marker;

}

visualization_msgs::Marker generatePredictMarker(prediction_box predict_box, int id, ros::Time loc_time)
{
    visualization_msgs::Marker predict_line_list;
	predict_line_list.header.frame_id = "/map";
	predict_line_list.header.stamp = loc_time;
    predict_line_list.ns = "basic_shapes";
    predict_line_list.type = visualization_msgs::Marker::LINE_LIST;
    predict_line_list.action = visualization_msgs::Marker::ADD;
    predict_line_list.lifetime = ros::Duration(0.2);

    predict_line_list.id = id;
    predict_line_list.scale.x = 0.1;
	predict_line_list.color.b = 1.0;
	predict_line_list.color.a = 1.0;

    geometry_msgs::Point p;
    int vert_num = predict_box.x.size();
    for (int c_vert = 0; c_vert < vert_num-1; c_vert++) {
        //start point
        p.x = predict_box.x[c_vert];
        p.y = predict_box.y[c_vert];
        p.z = 0;
        predict_line_list.points.push_back(p);
        //end point
        p.x = predict_box.x[c_vert+1];
        p.y = predict_box.y[c_vert+1];
        p.z = 0;
        predict_line_list.points.push_back(p);

    }
    return predict_line_list;
}

visualization_msgs::Marker generatePredictTextMarker(prediction_box predict_box, int id, ros::Time loc_time)
{
    visualization_msgs::Marker predict_text_marker;
	predict_text_marker.header.frame_id = "/map";
	predict_text_marker.header.stamp = loc_time;
	predict_text_marker.ns = "basic_shapes";
	predict_text_marker.type = visualization_msgs::Marker::TEXT_VIEW_FACING;
	predict_text_marker.action = visualization_msgs::Marker::ADD;
    predict_text_marker.lifetime = ros::Duration(0.1);

	//string list is blue
	predict_text_marker.color.g = 1.0;
	predict_text_marker.color.b = 1.0;
	predict_text_marker.color.a = 1.0;

	predict_text_marker.pose.position.z = 0;
	predict_text_marker.pose.orientation.x = 0.0;
	predict_text_marker.pose.orientation.y = 0.0;
	predict_text_marker.pose.orientation.z = 0.0;
	predict_text_marker.pose.orientation.w = 1.0;

	predict_text_marker.scale.x = 1;
	predict_text_marker.scale.y = 1;
	predict_text_marker.scale.z = 1;

    char text_str[300];
	memset(text_str, 0 ,300);
    double x_cen = predict_box.x_cen;
    double y_cen = predict_box.y_cen;

    predict_text_marker.id = id;
    predict_text_marker.pose.position.x = x_cen;
    predict_text_marker.pose.position.y = y_cen;
    predict_text_marker.pose.position.z = 0;
    sprintf(text_str,"id=%d",predict_box.id);
    std::string text(text_str);
    predict_text_marker.text = text;

    return predict_text_marker;

}



#endif