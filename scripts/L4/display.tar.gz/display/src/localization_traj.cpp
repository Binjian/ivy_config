//
// Created by wlh on 18-5-26.
//

//ros
#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseArray.h>
#include <nav_msgs/Path.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>

//std
#include <iostream>

ros::Publisher path_pub;
ros::Publisher traj_pub;
nav_msgs::Path path;
geometry_msgs::PoseArray traj;


//parameters
std::string pose_name, path_name, traj_name, frame_id;

void poseCallback(geometry_msgs::PoseStampedConstPtr msg)
{
    path.header = msg->header;
    path.poses.push_back(*msg);
    path_pub.publish(path);

    traj.header = msg->header;
    traj.poses.push_back(msg->pose);
    traj_pub.publish(traj);

    static tf::TransformBroadcaster br;
    tf::Transform trans;
    tf::Quaternion pose_q;

    trans.setOrigin(tf::Vector3(msg->pose.position.x, msg->pose.position.y,msg->pose.position.z));
    pose_q.setRPY(0, 0, tf::getYaw(msg->pose.orientation));
    trans.setRotation(pose_q);
    br.sendTransform( tf::StampedTransform(trans, msg->header.stamp, "map" , frame_id));
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "localization_paint");
    ros::NodeHandle nh;
    ros::NodeHandle pnh("~");

    pnh.param<std::string>("pose_name", pose_name, "rtk_pose");
    pnh.param<std::string>("path_name", path_name, "rtk_path");
    pnh.param<std::string>("traj_name", traj_name, "rtk_traj");
    pnh.param<std::string>("frame_id", frame_id, "base_link");

    path_pub = nh.advertise<nav_msgs::Path>(path_name, 10);
    traj_pub = nh.advertise<geometry_msgs::PoseArray>(traj_name,10);

    ros::Subscriber sub_pose = nh.subscribe(pose_name, 10, poseCallback);

    ros::spin();
    return 0;
}